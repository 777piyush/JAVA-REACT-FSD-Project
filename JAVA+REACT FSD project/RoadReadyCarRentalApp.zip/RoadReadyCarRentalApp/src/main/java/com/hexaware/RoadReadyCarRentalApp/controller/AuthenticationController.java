package com.hexaware.RoadReadyCarRentalApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.RoadReadyCarRentalApp.dto.LoginDto;
import com.hexaware.RoadReadyCarRentalApp.dto.RegisterDto;
import com.hexaware.RoadReadyCarRentalApp.dto.UserDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.AuthenticationResponse;
import com.hexaware.RoadReadyCarRentalApp.entity.User;
import com.hexaware.RoadReadyCarRentalApp.service.AuthenticationService;


@RestController
@RequestMapping("/api/authenticate")
@CrossOrigin("http://localhost:3000")
public class AuthenticationController {
	
	@Autowired
	private AuthenticationService authenticationService;
	
	// url = http//localhost:8080/api/authenticate/login
//	@PostMapping("/login")
//	public ResponseEntity<AuthenticationResponse> login (@RequestBody  User request) {
//		return ResponseEntity.ok(authenticationService.authenticate(request));
//	}
	
	// url = http//localhost:8080/api/authenticate/login
//	@PostMapping("/register")
//	public ResponseEntity<AuthenticationResponse> register (@RequestBody User request) {
//		AuthenticationResponse value = authenticationService.register(request);
//		return ResponseEntity.ok(value);
//	}
	
	@PostMapping(value = {"/login","/signin"})
	public ResponseEntity<AuthenticationResponse> login(@RequestBody LoginDto dto)
	{
		AuthenticationResponse token = authenticationService.authenticate(dto);
		/*JWTAuthResponse jwtAuthResponse = new JWTAuthResponse();
		jwtAuthResponse.setAccessToken(token);*/
		return ResponseEntity.ok(token);
	}

 
	@PostMapping(value = {"/register","/signup"})
	public ResponseEntity<String> register(@RequestBody RegisterDto dto)
	{
		String value = authenticationService.register(dto);
		return new ResponseEntity<>(value, HttpStatus.CREATED);
	}
}


package com.hexaware.RoadReadyCarRentalApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.ReviewDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.Review;
import com.hexaware.RoadReadyCarRentalApp.service.ReviewService;

@RestController
@RequestMapping("/api/reviews")
@CrossOrigin("*")
public class ReviewController {
	@Autowired
	private ReviewService reviewService;

	// url = http//localhost:8080/api/reviews/add
	@PostMapping("/add")
	public ResponseEntity<ReviewDTO> createReview(@RequestBody ReviewDTO reviewDTO) throws ResourceNotFoundException {
		ReviewDTO createdReview = reviewService.createReview(reviewDTO);
		return new ResponseEntity<>(createdReview, HttpStatus.CREATED);
	}

	// url = http//localhost:8080/api/reviews/getById/2
	@GetMapping("/getById/{id}")
	public ResponseEntity<ReviewDTO> getReviewById(@PathVariable("id") Long id) throws ResourceNotFoundException {
		ReviewDTO reviewDTO = reviewService.getReviewById(id);
		return ResponseEntity.ok(reviewDTO);
	}
	
	// url = http//localhost:8080/api/reviewsgetAll
	@GetMapping("/getAll")
	public ResponseEntity<List<ReviewDTO>> getAllReviews() throws NoDataFoundException {
		List<ReviewDTO> reviews = reviewService.getAllReviews();
		return ResponseEntity.ok(reviews);
	}

	// url = http//localhost:8080/api/reviews/update/2
	@PutMapping("/update/{id}")
	public ResponseEntity<ReviewDTO> updateReview(@PathVariable("id") Long id, @RequestBody ReviewDTO reviewDTO)
			throws ResourceNotFoundException {
		ReviewDTO updatedReview = reviewService.updateReview(id, reviewDTO);
		return ResponseEntity.ok(updatedReview);
	}

	// url = http//localhost:8080/api/reviews/delete/2
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> deleteReview(@PathVariable("id") Long id) throws ResourceNotFoundException {
		reviewService.deleteReview(id);
		return ResponseEntity.noContent().build();
	}

	// url = http//localhost:8080/api/reviews/car/2
	@GetMapping("/car/{carId}")
	public ResponseEntity<List<ReviewDTO>> getReviewsByCarId(@PathVariable("carId") Long carId)
			throws ResourceNotFoundException {
		List<ReviewDTO> reviews = reviewService.getReviewsByCarId(carId);
		return ResponseEntity.ok(reviews);
	}

	// url = http//localhost:8080/api/reviews/user/2
	@GetMapping("/user/{userId}")
	public ResponseEntity<List<ReviewDTO>> getReviewsByUserId(@PathVariable("userId") Long userId)
			throws ResourceNotFoundException {
		List<ReviewDTO> reviews = reviewService.getReviewsByUserId(userId);
		return ResponseEntity.ok(reviews);
	}

//	@GetMapping("/user")
//	public ResponseEntity<List<ReviewDTO>> getReviewsByUserId(@RequestParam("id") Long userId)
//	        throws ResourceNotFoundException {
//	    List<ReviewDTO> reviews = reviewService.getReviewsByUserId(userId);
//	    return ResponseEntity.ok(reviews);
//	}

	
	// url = http//localhost:8080/api/reviews/rating/4
	@GetMapping("/rating/{rating}")
	public ResponseEntity<List<ReviewDTO>> getReviewsWithRatingGreaterThanEqual(@PathVariable("rating") int rating)
			throws ResourceNotFoundException {
		List<ReviewDTO> reviews = reviewService.getReviewsWithRatingGreaterThanEqual(rating);
		return ResponseEntity.ok(reviews);
	}

	// url = http//localhost:8080/api/reviews/search
	@GetMapping("/search")
	public ResponseEntity<List<ReviewDTO>> searchReviewsByKeyword(@RequestParam("keyword") String keyword)
			throws ResourceNotFoundException {
		List<ReviewDTO> reviews = reviewService.searchReviewsByKeyword(keyword);
		return ResponseEntity.ok(reviews);
	}

	// url = http//localhost:8080/api/reviews/car/2/rating/4
	@GetMapping("/car/{carId}/rating/{rating}")
	public ResponseEntity<List<ReviewDTO>> getReviewsByCarIdAndRatingGreaterThanEqual(@PathVariable("carId") Long carId,
			@PathVariable("rating") int rating) {
		List<ReviewDTO> reviews = reviewService.getReviewsByCarIdAndRatingGreaterThanEqual(carId, rating);
		return ResponseEntity.ok(reviews);
	}

	// url = http//localhost:8080/api/reviews/car/2/count
	@GetMapping("/car/{carId}/count")
	public ResponseEntity<Long> countReviewsByCarId(@PathVariable("carId") Long carId)
			throws ResourceNotFoundException {
		Long count = reviewService.countReviewsByCarId(carId);
		return ResponseEntity.ok(count);
	}

	// url = http//localhost:8080/api/reviews/user/2
	@DeleteMapping("/user/{userId}")
	public ResponseEntity<Void> deleteReviewsByUserId(@PathVariable("userId") Long userId)
			throws ResourceNotFoundException {
		reviewService.deleteReviewsByUserId(userId);
		return ResponseEntity.noContent().build();
	}

	// url = http//localhost:8080/api/reviews/car/2
	@DeleteMapping("/car/{carId}")
	public ResponseEntity<Void> deleteReviewsByCarId(@PathVariable("carId") Long carId)
			throws ResourceNotFoundException {
		reviewService.deleteReviewsByCarId(carId);
		return ResponseEntity.noContent().build();
	}
	@GetMapping("/car/averageRating")
    public ResponseEntity<Double> getAverageRatingByCarId(@RequestParam("carId") Long carId) {
        Double averageRating = reviewService.getAverageRatingByCarId(carId);
        return ResponseEntity.ok(averageRating);
    }
	
	
}

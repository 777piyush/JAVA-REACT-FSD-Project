package com.hexaware.RoadReadyCarRentalApp.service;

import java.util.List;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.UserDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.User;

public interface UserService {
//    User createUser(User user);
    UserDTO getUserById(Long id) throws ResourceNotFoundException;
    List<UserDTO> getAllUsers() throws NoDataFoundException;
    UserDTO updateUser(Long id, UserDTO userDTO) throws ResourceNotFoundException;
    void deleteUser(Long id) throws ResourceNotFoundException;
}

package com.hexaware.RoadReadyCarRentalApp.service;

import java.time.LocalDateTime;
import java.util.List;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.ReservationDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.Reservation;
import com.hexaware.RoadReadyCarRentalApp.entity.Reservation.ReservationStatus;

public interface ReservationService {
	ReservationDTO makeReservation(ReservationDTO reservationdto) throws ResourceNotFoundException, NoDataFoundException;

	ReservationDTO getReservationById(Long id) throws ResourceNotFoundException;

	List<ReservationDTO> getAllReservations() throws NoDataFoundException;

	List<ReservationDTO> getReservationsByUserId(Long userId) throws ResourceNotFoundException;

	List<ReservationDTO> getReservationsByCarId(Long carId) throws ResourceNotFoundException;

	void cancelReservation(Long reservationId) throws ResourceNotFoundException;
	
	boolean isCarAvailable(Long carId, LocalDateTime pickupDateTime, LocalDateTime dropOffDateTime);

	boolean updateReservationStatus(Long id, ReservationStatus newStatus) throws ResourceNotFoundException;


}

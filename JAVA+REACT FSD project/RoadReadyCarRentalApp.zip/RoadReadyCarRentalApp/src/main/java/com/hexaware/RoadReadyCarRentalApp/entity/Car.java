package com.hexaware.RoadReadyCarRentalApp.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cars")
public class Car {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	private String brand;
	private String model;
	private String color;
	private Double price;
	private Boolean availability;
	private String location;
	private String description;
	
	public enum FuelType{
		PETROL,
		DIESEL,
		ELECTRIC,
		HYBRID,
		CNG
	}
	
	@Enumerated(EnumType.STRING)
	@Column(name="fuel_type")
	private FuelType fuelType;
	
	public enum TransmissionType{
		MANUAL,
		AUTOMATIC
	}
	
	@Enumerated(EnumType.STRING)
	@Column(name="transmission_type")
	private TransmissionType transmissionType;
	
	public enum CarType{
		HATCHBACK,
		SEDAN,
		SUV,
		MUV
	}
	@Enumerated(EnumType.STRING)
	@Column(name="car_type")
	private CarType carType;
	
	
	@OneToMany(mappedBy ="car", cascade = CascadeType.ALL)
	private List<Review> reviewList = new ArrayList<>();
	
	@OneToMany(mappedBy = "car",cascade = CascadeType.ALL)
	private List<Reservation> reservationList = new ArrayList<>();

		
}

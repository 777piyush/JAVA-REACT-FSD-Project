package com.hexaware.RoadReadyCarRentalApp.service.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.UserDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.User;
import com.hexaware.RoadReadyCarRentalApp.repository.UserRepository;
import com.hexaware.RoadReadyCarRentalApp.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	private static final Logger logger = LoggerFactory.getLogger(ReservationServiceImpl.class);

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ModelMapper modelMapper;

//	@Override
//	public User createUser(User user) {
//		logger.info("Creating user: {}", user);
//		User savedUser = userRepository.save(user);
//		logger.debug("User created successfully with ID: {}", savedUser.getId());
//		return savedUser;
//	}

	@Override
	public UserDTO getUserById(Long id) throws ResourceNotFoundException {
		logger.info("Fetching user by ID: {}", id);
		User userById = userRepository.findById(id).orElseThrow(() -> {
			logger.error("User not found with ID: {}", id);
			return new ResourceNotFoundException("User", "id", id);
		});
		logger.debug("Fetched user: {}", userById);
		UserDTO userByIdDTO = modelMapper.map(userById, UserDTO.class);
		return userByIdDTO;
	}

	@Override
	public List<UserDTO> getAllUsers() throws NoDataFoundException {
		logger.info("Fetching all users");
		List<User> userList = userRepository.findAll();

		if (userList.isEmpty()) {
			logger.error("No users found");
			throw new NoDataFoundException("No Users found.");
		}

		List<UserDTO> userDTOList = new ArrayList<>();

		for (User user : userList) {
			userDTOList.add(modelMapper.map(user, UserDTO.class));
		}
		logger.debug("Fetched users: {}", userDTOList.size());
		return userDTOList;
	}

	@Override
	public UserDTO updateUser(Long id, UserDTO userDTO) throws ResourceNotFoundException {
		logger.info("Updating user with ID: {}", id);
		UserDTO updatedUserDTO = null;
		User existingUser = userRepository.findById(id).orElseThrow(() -> {
			logger.error("User not found with ID: {}", id);
			return new ResourceNotFoundException("User", "id", id);
		});

		existingUser.setFirstName(userDTO.getFirstName());
		existingUser.setLastName(userDTO.getLastName());
		existingUser.setEmail(userDTO.getEmail());
		existingUser.setUsername(userDTO.getUsername());
		existingUser.setPhoneNumber(userDTO.getPhoneNumber());
//			 existingUser.setPassword(userDTO.getPassword());
//		existingUser.setRoles(userDTO.getRole());

		User updatedUser = userRepository.save(existingUser);

		updatedUserDTO = modelMapper.map(updatedUser, UserDTO.class);
		logger.debug("User updated successfully: {}", updatedUserDTO);
		return updatedUserDTO;
	}

	@Override
	public void deleteUser(Long id) throws ResourceNotFoundException {
		logger.info("Deleting user with ID: {}", id);
		userRepository.findById(id).orElseThrow(() -> {
			logger.error("User not found with ID: {}", id);
			return new ResourceNotFoundException("User", "id", id);
		});
		logger.debug("User deleted successfully with ID: {}", id);
		userRepository.deleteById(id);

	}

}

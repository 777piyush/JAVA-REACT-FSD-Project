package com.hexaware.RoadReadyCarRentalApp.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.hexaware.RoadReadyCarRentalApp.security.JwtAuthenticationEntryPoint;
import com.hexaware.RoadReadyCarRentalApp.security.JwtAuthenticationFilter;


@Configuration
@EnableWebSecurity
public class SecurityConfig {
//	@Autowired
//	private JwtAuthenticationFilter jwtAuthenticationFilter;
//	@Autowired
//	private CustomLogoutHandler logoutHandler;

//	private final CustomLogoutHandler logoutHandler;
//
//	public SecurityConfig(UserDetailsServiceImp userDetailsServiceImp, JwtAuthenticationFilter jwtAuthenticationFilter,
//			CustomLogoutHandler logoutHandler) {
//		this.userDetailsServiceImp = userDetailsServiceImp;
//		this.jwtAuthenticationFilter = jwtAuthenticationFilter;
//		this.logoutHandler = logoutHandler;
//	}

//	@Bean
//	SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

//		http.csrf(AbstractHttpConfigurer::disable).authorizeHttpRequests((authorize) ->
		// authorize.anyRequest().authenticated()
//		authorize
//				.requestMatchers("/api/authenticate/login**", "/api/authenticate/register**").permitAll()
//				.requestMatchers("/api/users/all**","/api/cars/addCar**","/api/cars/updateCar**","/api/cars/delete**","/api/reservations/updateStatus/**").hasAuthority("ADMIN")
//				.requestMatchers("/api/users/update/**","/api/reservations/make**","/api/reviews/add**","/api/reviews/update**").hasAuthority("USER")
//				//.requestMatchers("/api/users/userById**","/api/users/delete**").hasAnyAuthority("USER","ADMIN")
//				.anyRequest().authenticated())
//				.exceptionHandling(exception -> exception.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))
//				.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
//		http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
//		http.exceptionHandling(e -> e
//				.accessDeniedHandler((request, response, accessDeniedException) -> response.setStatus(403))
//				.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)));
//		http.logout(l -> l.logoutUrl("/logout").addLogoutHandler(logoutHandler).logoutSuccessHandler(
//				(request, response, authentication) -> SecurityContextHolder.clearContext()));
		
//		authorize.anyRequest().permitAll());
		
//		return http.build();

//	}

	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
		return configuration.getAuthenticationManager();
	}
	
	private UserDetailsService userDetailsService;
	private JwtAuthenticationEntryPoint authenticationEntryPoint;
	private JwtAuthenticationFilter jwtAuthenticationFilter;
	public SecurityConfig(UserDetailsService userDetailsService,
							JwtAuthenticationEntryPoint authenticationEntryPoint,
							JwtAuthenticationFilter jwtAuthenticationFilter) {
		this.userDetailsService = userDetailsService;
		this.authenticationEntryPoint = authenticationEntryPoint;
		this.jwtAuthenticationFilter = jwtAuthenticationFilter;
	}
	
//	@Bean
//	SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception
//	{
//		httpSecurity.csrf(AbstractHttpConfigurer::disable)
//			.authorizeHttpRequests((authorize) ->
//			authorize
//			.requestMatchers("/api/authenticate/**").permitAll()
//			.anyRequest().authenticated()
////			authorize.requestMatchers( "/api/**").permitAll().
////			requestMatchers("/api/event/delete/**").permitAll()
////			.requestMatchers("/api/authenticate/**").permitAll()
////			.requestMatchers("/api/event/**").permitAll()
////			.anyRequest().authenticated())
//			.exceptionHandling(exception -> exception.authenticationEntryPoint(authenticationEntryPoint))
//			.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
//		
//			httpSecurity.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
////			authorize.anyRequest().permitAll());
//			return httpSecurity.build();
//	}
	
	
	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
	    httpSecurity.csrf(AbstractHttpConfigurer::disable)
	        .authorizeHttpRequests((authorize) ->
	            authorize
	                .requestMatchers("/api/authenticate/**").permitAll()
	                
	            .requestMatchers("/api/cars/priceLessThan/**").permitAll()
	            .requestMatchers("/api/users/update/**","/api/reservations/make**","/api/reviews/add**","/api/reviews/update**").hasAuthority("ROLE_USER")
	            .requestMatchers("/api/users/all**","/api/cars/addCar**","/api/cars/updateCar**","/api/cars/delete**","/api/reservations/updateStatus/**").hasAuthority("ROLE_ADMIN")
	                .anyRequest().authenticated())
	        .exceptionHandling(exception -> exception.authenticationEntryPoint(authenticationEntryPoint))
	        .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

	    httpSecurity.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

	    return httpSecurity.build();
	}

}

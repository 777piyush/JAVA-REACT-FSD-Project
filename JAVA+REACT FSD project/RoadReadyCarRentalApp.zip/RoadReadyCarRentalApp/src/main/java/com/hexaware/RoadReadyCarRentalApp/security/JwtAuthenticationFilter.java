package com.hexaware.RoadReadyCarRentalApp.security;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;



import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
	
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	@Autowired
	private UserDetailsService userDetailsImp;
	public static String CURRENT_USER = "";
	
//	@Override
//	protected void doFilterInternal( HttpServletRequest request, 
//									 HttpServletResponse response, 
//									 FilterChain filterChain)
//			throws ServletException, IOException {
//		
//		 String authHeader = request.getHeader("Authorization");
//
//	        if(authHeader == null || !authHeader.startsWith("Bearer ")) {
//	            filterChain.doFilter(request,response);
//	            return;
//	        }
//
//	        String token = authHeader.substring(7);
//	        String username = jwtTokenProvider.getUsername(token);
//
//	        if(username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
//
//	            UserDetails userDetails = userDetailsImp.loadUserByUsername(username);
//
//
//	            if(jwtTokenProvider.isValid(token, userDetails)) {
//	                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
//	                        userDetails, null, userDetails.getAuthorities()
//	                );
//
//	                authToken.setDetails(
//	                        new WebAuthenticationDetailsSource().buildDetails(request)
//	                );
//
//	                SecurityContextHolder.getContext().setAuthentication(authToken);
//	            }
//	        }
//	        filterChain.doFilter(request, response);
//
//	}
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		// get jwt token from http request
		String token = getTokenFromRequest(request);
		// validate token
		if(StringUtils.hasText(token) && jwtTokenProvider.validateToken(token))
		{
			// get username from token
			String username = jwtTokenProvider.getUsername(token);
			CURRENT_USER  = username;
			// load user name
			UserDetails  userDetails = userDetailsImp.loadUserByUsername(username);
			UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
					userDetails, null, userDetails.getAuthorities());
			authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
			SecurityContextHolder.getContext().setAuthentication(authenticationToken);
		}
		filterChain.doFilter(request, response);
	}
	private String getTokenFromRequest(HttpServletRequest request)
	{
		String bearerToken = request.getHeader("Authorization");
		if(StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer "))
		{
			return bearerToken.substring(7, bearerToken.length());
		}
		return null;
	}
}

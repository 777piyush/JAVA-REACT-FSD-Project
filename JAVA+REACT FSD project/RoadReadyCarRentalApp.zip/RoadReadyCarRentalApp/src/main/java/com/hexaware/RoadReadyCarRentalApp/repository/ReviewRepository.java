package com.hexaware.RoadReadyCarRentalApp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hexaware.RoadReadyCarRentalApp.dto.ReviewDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.Review;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
	List<Review> findByCarId(Long carId);

	List<Review> findByUserId(Long userId);

	List<Review> findByRatingGreaterThanEqual(int rating);

	List<Review> findByCommentContainingIgnoreCase(String keyword);

	List<Review> findByCarIdAndRatingGreaterThanEqual(Long carId, int rating);

	Long countByCarId(Long carId);

	void deleteByUserId(Long userId);

	void deleteByCarId(Long carId);


	@Query("SELECT AVG(r.rating) FROM Review r WHERE r.car.id = :carId")
    Double findAverageRatingByCarId(@Param("carId") Long carId);
}

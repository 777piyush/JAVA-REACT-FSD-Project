package com.hexaware.RoadReadyCarRentalApp.service;

import java.util.List;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.ReviewDTO;


public interface ReviewService {
    ReviewDTO createReview(ReviewDTO reviewDTO) throws ResourceNotFoundException;
    ReviewDTO getReviewById(Long id) throws ResourceNotFoundException;
    List<ReviewDTO> getAllReviews() throws NoDataFoundException;
    ReviewDTO updateReview(Long id, ReviewDTO reviewDTO) throws ResourceNotFoundException;
    void deleteReview(Long id) throws ResourceNotFoundException;
    
    List<ReviewDTO> getReviewsByCarId(Long carId) throws ResourceNotFoundException;
    List<ReviewDTO> getReviewsByUserId(Long userId) throws ResourceNotFoundException;
    List<ReviewDTO> getReviewsWithRatingGreaterThanEqual(int rating) throws ResourceNotFoundException;
    List<ReviewDTO> searchReviewsByKeyword(String keyword) throws ResourceNotFoundException;
    List<ReviewDTO> getReviewsByCarIdAndRatingGreaterThanEqual(Long carId, int rating);
    Long countReviewsByCarId(Long carId) throws ResourceNotFoundException;
    void deleteReviewsByUserId(Long userId) throws ResourceNotFoundException;
    void deleteReviewsByCarId(Long carId) throws ResourceNotFoundException;
	
	Double getAverageRatingByCarId(Long carId);
    
}

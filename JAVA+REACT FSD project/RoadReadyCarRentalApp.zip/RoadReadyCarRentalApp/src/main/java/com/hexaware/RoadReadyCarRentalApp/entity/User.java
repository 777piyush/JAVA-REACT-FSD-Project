package com.hexaware.RoadReadyCarRentalApp.entity;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="users")
public class User {//implements UserDetails{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	@NotEmpty(message = "First name is required")
    private String firstName;
    @NotEmpty(message = "Last name is required")
    private String lastName;
  //@Email(message = "Invalid email address")
    @NotEmpty(message = "Invalid email address")
    private String email;
    
    @NotEmpty(message = "Username is required")
    @Size(min = 6, max = 20, message = "Username must be between 6 and 20 characters")
    //@Pattern(regexp = "[a-zA-Z0-9_-]+", message = "Username can only contain letters, numbers, underscores, and hyphens")
    private String username;
    
 // Password validation can be added if needed
    // For example:
    // @NotBlank(message = "Password is required")
    // @Size(min = 8, message = "Password must be at least 8 characters long")
	private String password;
	
	@Pattern(regexp = "\\d{10}", message = "Phone number must be 10 digits")
	@NotEmpty(message = "Phone number is required")
	private String phoneNumber;
	
	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
	private List<Reservation> reservationList = new ArrayList<>() ;
	
	@OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
	private List<Review> reviewList = new ArrayList<>() ;
	
//	public enum Role{
//		USER,
//		ADMIN
//	}
//	
//	@NotNull(message = "Role is required")
//	@Enumerated(EnumType.STRING)
//	@Column(name="role")
//	private Role role;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "users_roles", joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"))
	private Set<Role> roles;
	
	
//	@Override
//	public Collection<? extends GrantedAuthority> getAuthorities() {
//		return List.of(new SimpleGrantedAuthority(role.name()));
//	}
//
//	@Override
//	public boolean isAccountNonExpired() {
//		// TODO Auto-generated method stub
//		return true;
//	}
//
//	@Override
//	public boolean isAccountNonLocked() {
//		// TODO Auto-generated method stub
//		return true;
//	}
//
//	@Override
//	public boolean isCredentialsNonExpired() {
//		// TODO Auto-generated method stub
//		return true;
//	}
//
//	@Override
//	public boolean isEnabled() {
//		// TODO Auto-generated method stub
//		return true;
//	}


}

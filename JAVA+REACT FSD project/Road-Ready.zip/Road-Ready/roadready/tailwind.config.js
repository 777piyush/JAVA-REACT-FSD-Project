/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        customColor: '#2A352B', // Use the hexadecimal color representation
      },
    },
  },
  plugins: [],
}